﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManpahulSinghITD_18018
{
    public partial class Form1 : Form
    {
        string op1;
        string op2;
        string operations;
        bool performed = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void num_buttons_click(object sender, EventArgs e)
        {
            if (performed)
            {
                textBox1.Text = string.Empty;
            }
            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + button.Text;
            performed = false;
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            op1 = string.Empty;
            op2 = string.Empty;
            operations = string.Empty;
            label1.Text = string.Empty;
        }

        private void buttonCE_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
        }

        private void opbuttonsclick(object sender, EventArgs e)
        {
            op1 = textBox1.Text;
            Button button = (Button)sender;
            operations = button.Text;
            label1.Text = textBox1.Text + " " + operations;
            performed = true;
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            op2 = textBox1.Text;
            label1.Text = op1 + " " + operations + " " + op2 + " " + "=";
            double a, b;
            a = double.Parse(op1);
            b = double.Parse(op2);

            switch(operations)
            {
                case "+":
                    {
                        textBox1.Text = (a + b).ToString();
                        break;
                    }

                case "-":
                    {
                        textBox1.Text = (a - b).ToString();
                        break;
                    }

                case "*":
                    {
                        textBox1.Text = (a * b).ToString();
                        break;
                    }

                case "/":
                    {
                        textBox1.Text = (a / b).ToString();
                        break;
                    }

                default:
                    {
                        break;
                    }

            }
        }
    }
}
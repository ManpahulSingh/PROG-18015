﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MSinghAssignment01
{



    public partial class Form1 : Form
    {
        /*Declared an array equal to the number of seats to store the reservation data*/
        string[,] reservationdata = new string[5, 3];
        /*Declared an array to store waiting list information*/
        string[] waitinglist = new string[10];

        /*Two variables used for reffering to the arrays*/
        int r=999, c=999;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*Emptied out all the arrays and textboxes on application start*/
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    reservationdata[i, j] = string.Empty;
                }
            }

            for (int i = 0; i < 10; i++)
            {
                waitinglist[i] = "";
            }

            richTextBox1.Text = string.Empty;
            textBox1.Text = string.Empty;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            r = listBox1.SelectedIndex;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            c = listBox2.SelectedIndex;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter a name");
            }

            else
            {
                
                try
                {
                    if (reservationdata[r, c] == string.Empty)
                    {
                        reservationdata[r, c] = textBox1.Text;
                        MessageBox.Show("The seat has been booked successfully");
                    }

                    else
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                if (reservationdata[i, j] == string.Empty)
                                {
                                    throw new EmptySeat();
                                }
                            }
                        }
                            throw new Gtfooftheloop();

                    }
                }
                catch(Gtfooftheloop)
                {
                    MessageBox.Show("All seats are booked please add yourself to the waiting list. Your seat will be booked as soon as some other user cancels it");
                }
                catch (IndexOutOfRangeException)
                {
                    MessageBox.Show("Please select a seat");
                }
                catch(EmptySeat)
                {
                    MessageBox.Show("The seat is already booked to " + reservationdata[r, c] + " Try selecting some other ticket.");
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 1;
            b = 1;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (reservationdata[r, c] != string.Empty)
                {
                    reservationdata[r, c] = string.Empty;
                    MessageBox.Show("The ticket has been canceled");
                    for (int i = 0; i < 10; i++)
                    {
                        if (waitinglist[i] != string.Empty)
                        {
                            reservationdata[r, c] = waitinglist[i];
                            waitinglist[i] = string.Empty;
                            for (int j = 0; j < 10; j++)
                            {
                                waitinglist[j++] = waitinglist[j--];
                            }
                            throw new Gtfooftheloop();
                        }
                    }
                }
            }
            catch(Gtfooftheloop)
            {

            }

            catch(IndexOutOfRangeException)
            {

            }
            finally
            {
                richTextBox1.Text = "";
                for (int i = 0; i < 10; i++)
                {
                    if (richTextBox1.Text == "")
                    {
                        richTextBox1.Text = waitinglist[i];
                    }

                    else
                    {
                        richTextBox1.Text += "\n" + waitinglist[i];
                    }
                }
            }
        }

        /*On pressing add to waiting list button*/
        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            try
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (reservationdata[i, j] == "")
                        {
                            throw new EmptySeat();
                        }
                    }
                }
                    

                    for (int x = 0; x < 10; x++)
                    {
                        if (waitinglist[x] == "")
                        {
                        waitinglist[x] = textBox1.Text;
                            throw new Gtfooftheloop();
                        }
                    }

                throw new waitinglistfull();
            }
            catch (EmptySeat)
            {
                MessageBox.Show("Seats are empty please book one");
            }
            catch(Gtfooftheloop)
            {
                MessageBox.Show("The user has been added to the waiting list");
            }
            catch (waitinglistfull)
            {
                MessageBox.Show("The waiting list is full.....please come back later");
            }
            finally
            {
                for (int i = 0; i < 10; i++)
                {
                    if(richTextBox1.Text == "")
                    {
                        richTextBox1.Text = waitinglist[i];
                    }

                    else
                    {
                        richTextBox1.Text +="\n" + waitinglist[i];
                    }
                }
            }


        }

        /*This one was a real pain....please don't open this it's really lengthy*/
        private void button1_Click(object sender, EventArgs e)
        {
            if (reservationdata[0, 0] == string.Empty)
            {
                button5.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button5.BackColor = Color.Red;
            }



            if (reservationdata[0, 1] == string.Empty)
            {
                button6.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button6.BackColor = Color.Red;
            }


            if (reservationdata[0, 2] == string.Empty)
            {
                button7.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button7.BackColor = Color.Red;
            }


            if (reservationdata[1, 0] == string.Empty)
            {
                button11.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button11.BackColor = Color.Red;
            }



            if (reservationdata[1, 1] == string.Empty)
            {
                button10.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button10.BackColor = Color.Red;
            }



            if (reservationdata[1, 2] == string.Empty)
            {
                button9.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button9.BackColor = Color.Red;
            }


            if (reservationdata[2, 0] == string.Empty)
            {
                button14.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button14.BackColor = Color.Red;
            }



            if (reservationdata[2, 1] == string.Empty)
            {
                button13.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button13.BackColor = Color.Red;
            }


            if (reservationdata[2, 2] == string.Empty)
            {
                button12.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button12.BackColor = Color.Red;
            }


            if (reservationdata[3, 0] == string.Empty)
            {
                button17.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button17.BackColor = Color.Red;
            }



            if (reservationdata[3, 1] == string.Empty)
            {
                button16.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button16.BackColor = Color.Red;
            }


            if (reservationdata[3, 2] == string.Empty)
            {
                button15.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button15.BackColor = Color.Red;
            }


            if (reservationdata[4, 0] == string.Empty)
            {
                button20.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button20.BackColor = Color.Red;
            }



            if (reservationdata[4, 1] == string.Empty)
            {
                button19.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button19.BackColor = Color.Red;
            }


            if (reservationdata[4, 2] == string.Empty)
            {
                button18.BackColor = Control.DefaultBackColor;
            }

            else
            {
                button18.BackColor = Color.Red;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (reservationdata[i, j] == "")
                    {
                        reservationdata[i, j] = "TEST USER";
                    }
                    else
                    {

                    }
                }
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    reservationdata[i, j] = string.Empty;
                }
            }

            for (int i = 0; i < 10; i++)
            {
                waitinglist[i] = string.Empty;
            }

            richTextBox1.Text = "";
            for (int i = 0; i < 10; i++)
            {
                if (richTextBox1.Text == "")
                {
                    richTextBox1.Text = waitinglist[i];
                }

                else
                {
                    richTextBox1.Text += "\n" + waitinglist[i];
                }
            }
        }

        #region 'Buttonsss'
        private void button5_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 0;
            b = 0;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 0;
            b = 1;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 0;
            b = 2;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 1;
            b = 0;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 1;
            b = 2;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 2;
            b = 0;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 2;
            b = 1;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 2;
            b = 2;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 3;
            b = 0;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 3;
            b = 1;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 3;
            b = 2;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 4;
            b = 0;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 4;
            b = 1;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            int a, b;

            a = 4;
            b = 2;

            if (reservationdata[a, b] == string.Empty)
            {
                MessageBox.Show("The seat is not currently booked");
            }

            else
            {
                MessageBox.Show("The seat is currently booked by " + reservationdata[a, b]);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {

        }
#endregion
    }


}

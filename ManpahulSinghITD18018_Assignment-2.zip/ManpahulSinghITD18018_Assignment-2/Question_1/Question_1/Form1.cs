﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_1
{
    public partial class Form1 : Form
    {
        bool tb2;
        bool tb3;
        string name;
        int hours_worked;
        double salaryperhour;
        double salary;
        bool namevalidate;
        bool hoursvalidate;
        bool allset;
        public Form1()
        {
            InitializeComponent();
            label4.Text = string.Empty;
            label5.Text = string.Empty;
            label6.Text = string.Empty;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if(allset)
            {
                Employee accountant = new Employee(name, hours_worked, salaryperhour);
                salary = accountant.calculateSalary();
            }

            System.Windows.Forms.MessageBox.Show("The salary of " + name + "is " + salary.ToString() + @"$");

        }

        private void textValidate(object sender, EventArgs e)
        {
            label4.Text = string.Empty;
            label5.Text = string.Empty;
            label6.Text = string.Empty;
            name = textBox1.Text;
            tb2 = int.TryParse(textBox2.Text, out hours_worked);
            tb3 = double.TryParse(textBox3.Text, out salaryperhour);

            for (int i = 0; i < name.Length; i++)
            {
                if (!char.IsLetter(name, i))
                {
                    namevalidate = false;
                    break;
                }
                else
                {
                    namevalidate = true;
                }
            }

            for (int i = 0; i < hours_worked.ToString().Length; i++)
            {
                if (!char.IsDigit(hours_worked.ToString(), i))
                {
                    hoursvalidate = false;
                    break;
                }
                else
                {
                    hoursvalidate = true;
                }
            }

            if (!namevalidate)
            {
                label4.Text = "Invalid name";
                allset = false;
            }

            else if (name == "")
            {
                label4.Text = "Please enter a name";
                allset = false;
            }

            else if (!hoursvalidate)
            {
                label5.Text = "Invalid hours worked";
                allset = false;
            }

            else if (!tb2)
            {
                label5.Text = "Hours worked can be a positive non zero integer only and can not be empty";
                allset = false;
            }

            else if (hours_worked <= 0)
            {
                label5.Text = "Hours worked can not be equal to or less than zero";
                allset = false;
            }

            if (!tb3)
            {
                label6.Text = "Salary per hour can be a positive non zero integer only and can not be empty";
                allset = false;
            }

            else
            {
                allset = true;
            }

        }
    }
}

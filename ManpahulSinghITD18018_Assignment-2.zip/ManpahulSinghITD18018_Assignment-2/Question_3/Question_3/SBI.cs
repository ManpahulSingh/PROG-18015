﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    class SBI : Bank
    {
        double Bank.getRateOfInterest(double Pamount, double time)
        {
            double Famount = (Pamount * time * 8) / 100;
            return Famount;
        }
    }
}
